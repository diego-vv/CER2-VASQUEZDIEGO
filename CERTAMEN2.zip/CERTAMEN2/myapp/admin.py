from django.contrib import admin
from .models import Entidad,Comunicado

admin.site.register(Entidad)
admin.site.register(Comunicado)

# Register your models here.
